package com.example.geektrust;

import java.io.File;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Main
{
    // Invest money in 3 different portfolio
    static double[] portfolioPercent = new double[3];

    enum Command
    {
        ALLOCATE,
        SIP,
        CHANGE,
        BALANCE,
        REBALANCE
    }

    /**
     * Main method for executing the file content Validations are not done. Assuming that the expected file content
     * details are communicated to the users.
     * 
     * @param args
     */
    public static void main(String[] args)
    {
        try (Stream<String> fileLines = Files.lines(new File(args[0]).toPath())) {
            List<String> lines = fileLines.map(String::trim).filter(s -> !s.matches(" ")).collect(Collectors.toList());
            investmentCalculation(lines);
        } catch (Exception e) {
            System.err.println("Exception Occured while processing " + e);
        }
    }

    /**
     * Process file content to calculate the investment and gain details
     * 
     * @param lines
     * @return Investment Object
     */
    public static Investment investmentCalculation(List<String> lines)
    {
        Investment investment = new Investment();
        for (String line : lines) {
            String[] instructions = line.trim().split(" ");
            Command command = Command.valueOf(instructions[0]);
            switch (command) {
                case ALLOCATE:
                    addInitialInvestment(instructions, investment);
                    break;
                case SIP:
                    addSip(instructions, investment);
                    break;
                case CHANGE:
                    changeGains(instructions, investment);
                    break;
                case BALANCE:
                    System.out.println(printBalance(instructions, investment));
                    break;
                case REBALANCE:
                    System.out.println(printRebalance(investment));
                    break;
            }
        }
        return investment;
    }

    /**
     * Calculate Gains of the investment, based on the input from file content
     * 
     * @param instructions
     * @param investment
     */
    public static void changeGains(String[] instructions, Investment investment)
    {
        String month = instructions[instructions.length - 1];
        List<Double> sipValues = Collections.emptyList();
        List<Double> investedValues = investment.getInitialInvestment();
        List<Double> updatedInvestment = new ArrayList<>();
        if (!month.equalsIgnoreCase("JANUARY")) {
            investedValues = investment.getLatestBalance();
            sipValues = investment.getSip();
        }
        calculateGainOrLoss(instructions, sipValues, investedValues, updatedInvestment);
        investment.setLatestBalance(updatedInvestment);
        Map<String, List<Double>> monthBalance = investment.getBalanceByMonth();
        monthBalance.put(month, updatedInvestment);
        investment.setBalanceByMonth(monthBalance);
    }

    /**
     * Calculate Gains of the investment.
     * 
     * @param instructions
     * @param sipValues
     * @param investedValues
     * @param updatedInvestment
     */
    private static void calculateGainOrLoss(String[] instructions, List<Double> sipValues, List<Double> investedValues,
        List<Double> updatedInvestment)
    {
        Pattern p = Pattern.compile("^-?\\d+\\.?\\d+");
        for (int i = 1; i < instructions.length - 1; i++) {
            Matcher m = p.matcher(instructions[i]);
            if (m.find()) {
                double sipValue = sipValues.isEmpty() ? 0 : sipValues.get(i - 1);
                double investedValue = investedValues.get(i - 1) + sipValue;
                double marketGainOrLossInPercentage = Double.parseDouble(m.group());
                double gainOrLossInAmountOfInvestedValue =
                    calculateGainOrLossValue(investedValue, marketGainOrLossInPercentage);
                double finalValueAfterLossOrGain = gainOrLossInAmountOfInvestedValue + investedValue;
                updatedInvestment.add(finalValueAfterLossOrGain);
            }
        }
    }

    private static double calculateGainOrLossValue(double initialValue, double gainOrLosspercentage)
    {
        return (initialValue * gainOrLosspercentage) / 100;
    }

    /**
     * Add initial investment value to object.
     * 
     * @param instructions
     * @param investment
     */
    public static void addInitialInvestment(String[] instructions, Investment investment)
    {
        double total = 0;
        List<Double> investmentValues = investment.getInitialInvestment();
        for (int i = 1; i < instructions.length; i++) {
            investmentValues.add(Double.parseDouble(instructions[i]));
            total += Double.parseDouble(instructions[i]);
        }
        investment.setInitialInvestment(investmentValues);
        calculatePercent(investmentValues, total);
    }

    /**
     * Add SIP values to investment object
     * 
     * @param instructions
     * @param investment
     */
    public static void addSip(String[] instructions, Investment investment)
    {
        List<Double> sipValues = investment.getSip();
        for (int i = 1; i < instructions.length; i++) {
            sipValues.add(Double.parseDouble(instructions[i]));
        }
        investment.setSip(sipValues);
    }

    /**
     * Calculate percentage value of each investment.
     * 
     * @param investment
     * @param total
     */
    public static void calculatePercent(List<Double> investment, double total)
    {
        for (int i = 0; i < investment.size(); i++) {
            portfolioPercent[i] = investment.get(i) / total;
        }
    }

    /**
     * PrintRebalance value for every six months.
     * 
     * @param investment
     * @return
     */
    public static String printRebalance(Investment investment)
    {
        StringBuilder sb = new StringBuilder("");
        if (investment.getBalanceByMonth().size() % 6 == 0) {
            Double totalGainOrLoss = investment.getLatestBalance().stream().mapToDouble(Double::doubleValue).sum();
            for (double percentage : portfolioPercent) {
                Double printValue = percentage * totalGainOrLoss;
                sb.append(printValue.shortValue());
                sb.append(" ");
            }
        } else {
            sb.append("CANNOT_REBALANCE");
        }
        return sb.toString();

    }

    /**
     * Print balance value for every month
     * 
     * @param instructions
     * @param investment
     * @return
     */
    public static String printBalance(String[] instructions, Investment investment)
    {
        StringBuilder sb = new StringBuilder("");
        String month = instructions[instructions.length - 1];
        List<Double> monthlyValues = investment.getBalanceByMonth().get(month);
        if (Objects.nonNull(monthlyValues)) {
            monthlyValues.stream().forEach(balance -> {
                sb.append(balance.shortValue());
                sb.append(" ");
            });
        }
        return sb.toString();
    }
}
