package com.example.geektrust;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Domain class for processing the data
 * 
 * @author Balachandar
 */
public class Investment
{
    List<Double> initialInvestment;

    List<Double> sip;

    List<Double> latestBalance;

    Map<String, List<Double>> balanceByMonth;

    Investment()
    {
        super();
        initialInvestment = new ArrayList<>();
        sip = new ArrayList<>();
        latestBalance = new ArrayList<>();
        balanceByMonth = new LinkedHashMap<>();
    }

    public List<Double> getInitialInvestment()
    {
        return initialInvestment;
    }

    public void setInitialInvestment(List<Double> initialInvestment)
    {
        this.initialInvestment = initialInvestment;
    }

    public List<Double> getSip()
    {
        return sip;
    }

    public void setSip(List<Double> sip)
    {
        this.sip = sip;
    }

    public Map<String, List<Double>> getBalanceByMonth()
    {
        return balanceByMonth;
    }

    public void setBalanceByMonth(Map<String, List<Double>> balanceByMonth)
    {
        this.balanceByMonth = balanceByMonth;
    }

    public List<Double> getLatestBalance()
    {
        return latestBalance;
    }

    public void setLatestBalance(List<Double> latestBalance)
    {
        this.latestBalance = latestBalance;
    }

}
