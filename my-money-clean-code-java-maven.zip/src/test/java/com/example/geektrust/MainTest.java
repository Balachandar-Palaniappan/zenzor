package com.example.geektrust;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertIterableEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;

class MainTest
{

    @Test
    void addInitialInvestment()
    {
        // Given
        Investment investment = new Investment();
        String[] initialValues = "ALLOCATE 6000 3000 1000".split(" ");
        // When
        Main.addInitialInvestment(initialValues, investment);
        // Then
        // Check initial investment is set
        assertEquals(3, investment.initialInvestment.size());
        // Check portfolioPercent is calculated
        assertEquals(3, Main.portfolioPercent.length);
    }

    @Test
    void addSip()
    {
        // Given
        Investment investment = new Investment();
        String[] sipValues = "SIP 2000 1000 500".split(" ");
        // When
        Main.addSip(sipValues, investment);
        // Then
        // Check SIP is set
        assertEquals(3, investment.getSip().size());
    }

    @Test
    void addGainsForMonthOfJanuray()
    {
        // Given
        Investment investment = new Investment();
        String[] initialValues = "ALLOCATE 6000 3000 1000".split(" ");
        String[] sipValues = "SIP 2000 1000 500".split(" ");
        String[] gainOrLossPercentage = "CHANGE 4.00% 10.00% 2.00% JANUARY".split(" ");

        String[] expectedValues = "6240.0 3300.0 1020.0".split(" ");
        String[] printBalance = "BALANCE JANUARY".split(" ");

        // When
        Main.addSip(sipValues, investment);
        Main.addInitialInvestment(initialValues, investment);
        Main.changeGains(gainOrLossPercentage, investment);
        // Then
        // Check initial investment is set
        assertEquals(3, investment.initialInvestment.size());
        // Check portfolioPercent is calculated
        assertEquals(3, Main.portfolioPercent.length);
        // Check SIP is set
        assertEquals(3, investment.getSip().size());
        // Check Gain is calculated is set
        assertIterableEquals(constructResult(expectedValues), investment.getLatestBalance());
        // Check gain for months
        assertEquals(1, investment.getBalanceByMonth().size());
        assertEquals("6240 3300 1020", Main.printBalance(printBalance, investment).trim());
    }

    @Test
    void addGainsForOtherMonths()
    {
        // Given
        Investment investment = new Investment();
        String[] initialValues = "ALLOCATE 6000 3000 1000".split(" ");
        String[] sipValues = "SIP 2000 1000 500".split(" ");
        String[] gainOrLossPercentageJan = "CHANGE 4.00% 10.00% 2.00% JANUARY".split(" ");
        String[] gainOrLossPercentageFeb = "CHANGE -10.00% 40.00% 0.00% FEBRUARY".split(" ");

        String[] expectedValues = "7416.0 6020.0 1520.0".split(" ");
        String[] printBalance = "BALANCE MARCH".split(" ");

        // When
        Main.addSip(sipValues, investment);
        Main.addInitialInvestment(initialValues, investment);
        Main.changeGains(gainOrLossPercentageJan, investment);
        Main.changeGains(gainOrLossPercentageFeb, investment);
        // Then
        // Check initial investment is set
        assertEquals(3, investment.initialInvestment.size());
        // Check portfolioPercent is calculated
        assertEquals(3, Main.portfolioPercent.length);
        // Check SIP is set
        assertEquals(3, investment.getSip().size());
        // Check Gain is calculated is set
        assertIterableEquals(constructResult(expectedValues), investment.getLatestBalance());
        // Check gain for months
        assertEquals(2, investment.getBalanceByMonth().size());
        assertEquals("", Main.printBalance(printBalance, investment));
        assertEquals("CANNOT_REBALANCE", Main.printRebalance(investment).trim());
    }

    @Test
    void addGainsForOtherMonthsAndRebalance()
    {
        // Given
        Investment investment = new Investment();
        String[] initialValues = "ALLOCATE 6000 3000 1000".split(" ");
        String[] sipValues = "SIP 2000 1000 500".split(" ");
        String[] gainOrLossPercentageJan = "CHANGE 4.00% 10.00% 2.00% JANUARY".split(" ");
        String[] gainOrLossPercentageFeb = "CHANGE -10.00% 40.00% 0.00% FEBRUARY".split(" ");
        String[] gainOrLossPercentageMar = "CHANGE 12.50% 12.50% 12.50% MARCH".split(" ");
        String[] gainOrLossPercentageApr = "CHANGE 8.00% -3.00% 7.00% APRIL".split(" ");
        String[] gainOrLossPercentageMay = "CHANGE 13.00% 21.00% 10.50% MAY".split(" ");
        String[] gainOrLossPercentageJun = "CHANGE 10.00% 8.00% -5.00% JUNE".split(" ");

        String[] printBalance = "BALANCE MARCH".split(" ");
        // When
        Main.addSip(sipValues, investment);
        Main.addInitialInvestment(initialValues, investment);
        Main.changeGains(gainOrLossPercentageJan, investment);
        Main.changeGains(gainOrLossPercentageFeb, investment);
        Main.changeGains(gainOrLossPercentageMar, investment);
        Main.changeGains(gainOrLossPercentageApr, investment);
        Main.changeGains(gainOrLossPercentageMay, investment);
        Main.changeGains(gainOrLossPercentageJun, investment);
        // Then
        // Check initial investment is set
        assertEquals(3, investment.initialInvestment.size());
        // Check portfolioPercent is calculated
        assertEquals(3, Main.portfolioPercent.length);
        // Check SIP is set
        assertEquals(3, investment.getSip().size());
        // Check gain for months
        assertEquals(6, investment.getBalanceByMonth().size());
        assertEquals("10593 7897 2272", Main.printBalance(printBalance, investment).trim());
        assertEquals("23622 11811 3937", Main.printRebalance(investment).trim());
    }

    private List<Double> constructResult(String[] initialValues)
    {
        List<Double> exceptedValues = new ArrayList<>();
        for (int i = 0; i < initialValues.length; i++) {
            exceptedValues.add(Double.parseDouble(initialValues[i]));
        }
        return exceptedValues;
    }

    @Test
    void investmentCalculation()
    {
        // Given
        String fileContent = "ALLOCATE 6000 3000 1000\n" + "SIP 2000 1000 500\n" + "CHANGE 4.00% 10.00% 2.00% JANUARY\n"
            + "CHANGE -10.00% 40.00% 0.00% FEBRUARY\n" + "CHANGE 12.50% 12.50% 12.50% MARCH\n"
            + "CHANGE 8.00% -3.00% 7.00% APRIL\n" + "CHANGE 13.00% 21.00% 10.50% MAY\n"
            + "CHANGE 10.00% 8.00% -5.00% JUNE\n" + "BALANCE MARCH\n" + "REBALANCE";
        List<String> lines = Arrays.asList(fileContent.split("\n"));
        // When
        Investment expectedvalue = Main.investmentCalculation(lines);
        // Then
        // Check investment object
        assertNotNull(expectedvalue.getBalanceByMonth());
    }
}
